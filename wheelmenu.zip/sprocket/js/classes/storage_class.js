(function () {
    'use strict';
    App.StorageClass = Ember.Object.extend({});
})();