(function () {
    'use strict';
    App.MessageView = Ember.View.extend({
        templateName:'message'
    });
})();