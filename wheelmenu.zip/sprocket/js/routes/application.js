(function () {
    'use strict';

    /*App.ApplicationRoute = Ember.Route.extend({
        beforeModel: function () {
            alert(App.utilities.getParamsByName('nw')?"exist":"not")
            alert('here')
            if (App.utilities.getParamsByName('nw')) {
                var toUrl = '/' + App.utilities.getParamsByName('nw');
                var code = App.utilities.getParamsByName('code'),
                    state = App.utilities.getParamsByName('state');
                App.utilities.redirectToUrl(location.href.split('?')[0] + '#/vimeo/authorize?state='+state + '&code='+code);
            }
            alert('end')
        }
    });*/
})();